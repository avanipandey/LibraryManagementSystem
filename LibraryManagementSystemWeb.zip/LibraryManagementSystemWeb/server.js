#!/usr/bin/env node
// LibraryManagementSystem web server: static UI + JSON API. Zero dependencies (Node 18+).
const http = require('http');
const fs = require('fs');
const path = require('path');
const store = require('./src/store');
const auth = require('./src/auth');

const PUBLIC_DIR = path.join(__dirname, 'public');
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon' };
const READ = ['books', 'sections', 'users', 'loans', 'reservations', 'fines'];
const WRITE = ['books', 'sections', 'users', 'loans', 'reservations'];
const COOKIE = 'lms_session';
const CSP = "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'";

const httpError = (status, message) => Object.assign(new Error(message), { status });

// ---------- routing ----------
const routes = [];
function route(method, pattern, access, handler, limit = 1024 * 1024) {
  const keys = [];
  const re = new RegExp('^' + pattern.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '$');
  routes.push({ method, re, keys, access, handler, limit });
}

// ---------- helpers ----------
function parseCookies(header = '') {
  const out = {};
  for (const part of header.split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    let size = 0;
    let tooBig = false;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) tooBig = true; else chunks.push(c);
    });
    req.on('end', () => {
      if (tooBig) return reject(httpError(413, 'That request is too large.'));
      if (!chunks.length) return resolve({});
      try {
        const body = JSON.parse(Buffer.concat(chunks).toString('utf8'));
        resolve(body && typeof body === 'object' ? body : {});
      } catch { reject(httpError(400, 'The request body is not valid JSON.')); }
    });
    req.on('error', reject);
  });
}

function sendJson(res, status, data) {
  const body = JSON.stringify(data ?? null);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(body), 'Cache-Control': 'no-store' });
  res.end(body);
}

function makeLimiter() {
  const attempts = new Map();
  return {
    check(ip) {
      const a = attempts.get(ip);
      if (a && a.until > Date.now()) throw httpError(429, 'Too many failed sign-in attempts. Try again in a few minutes.');
    },
    fail(ip) {
      const a = attempts.get(ip) || { count: 0, until: 0 };
      if (a.until && a.until <= Date.now()) { a.count = 0; a.until = 0; }
      if (++a.count >= 5) { a.until = Date.now() + 5 * 60 * 1000; a.count = 0; }
      attempts.set(ip, a);
    },
    clear(ip) { attempts.delete(ip); }
  };
}

function cookieHeader(req, value, maxAge) {
  const secure = process.env.COOKIE_SECURE === '1' || req.headers['x-forwarded-proto'] === 'https';
  return `${COOKIE}=${value}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${maxAge}${secure ? '; Secure' : ''}`;
}

// ---------- API routes ----------
route('GET', '/api/session', 'none', ({ user }) => ({
  user: user ? auth.publicView(user) : null,
  setupRequired: auth.needsSetup(),
  today: store.today(),
  libraryName: store.getSettings().libraryName
}));

function startSession(ctx, staff) {
  ctx.res.setHeader('Set-Cookie', cookieHeader(ctx.req, auth.createSession(staff.id), auth.SESSION_MS / 1000));
  return { user: auth.publicView(staff), today: store.today(), libraryName: store.getSettings().libraryName };
}

route('POST', '/api/setup', 'none', (ctx) => {
  if (!auth.needsSetup()) throw httpError(403, 'Setup is already complete. Sign in instead.');
  const created = auth.createStaff({ ...ctx.body, role: 'admin' });
  return startSession(ctx, { id: created.id, ...created });
});

route('POST', '/api/login', 'none', (ctx) => {
  ctx.limiter.check(ctx.ip);
  const staff = auth.verify(ctx.body.username, ctx.body.password);
  if (!staff) { ctx.limiter.fail(ctx.ip); throw httpError(401, 'Incorrect username or password.'); }
  ctx.limiter.clear(ctx.ip);
  return startSession(ctx, staff);
});

route('POST', '/api/logout', 'none', (ctx) => {
  auth.destroySession(parseCookies(ctx.req.headers.cookie)[COOKIE]);
  ctx.res.setHeader('Set-Cookie', cookieHeader(ctx.req, '', 0));
  return { ok: true };
});

route('GET', '/api/stats', 'any', () => store.stats());
route('GET', '/api/settings', 'any', () => store.getSettings());
route('PUT', '/api/settings', 'admin', ({ body }) => store.saveSettings(body));

route('GET', '/api/reports/:name/csv', 'any', ({ params, res }) => {
  const csv = store.reportCsv(params.name);
  res.writeHead(200, { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': `attachment; filename="${params.name}-report-${store.today()}.csv"`, 'Cache-Control': 'no-store' });
  res.end(csv);
});
route('GET', '/api/reports/:name', 'any', ({ params }) => store.report(params.name));

route('GET', '/api/backup', 'admin', ({ res }) => {
  const body = JSON.stringify(store.dump(), null, 2);
  res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Disposition': `attachment; filename="library-backup-${store.today()}.json"`, 'Cache-Control': 'no-store' });
  res.end(body);
});
route('POST', '/api/restore', 'admin', ({ body }) => store.restore(body) && { restored: true }, 20 * 1024 * 1024);

route('GET', '/api/staff', 'admin', () => auth.listStaff());
route('POST', '/api/staff', 'admin', ({ body }) => auth.createStaff(body));
route('PUT', '/api/staff/:id', 'admin', ({ params, body }) => auth.updateStaff(params.id, body));
route('DELETE', '/api/staff/:id', 'admin', ({ params, user }) => auth.removeStaff(params.id, user.id) && { deleted: true });

route('POST', '/api/loans/:id/return', 'any', ({ params }) => store.returnLoan(params.id));
route('POST', '/api/loans/:id/renew', 'any', ({ params }) => store.renewLoan(params.id));
route('POST', '/api/fines/:id/settle', 'any', ({ params, body }) => store.settleFine(params.id, body.how));
route('POST', '/api/reservations/:id/cancel', 'any', ({ params }) => store.cancelReservation(params.id));

const known = (list, name) => { if (!list.includes(name)) throw httpError(404, 'Not found.'); return name; };
route('GET', '/api/:collection', 'any', ({ params }) => store.list(known(READ, params.collection)));
route('POST', '/api/:collection', 'any', ({ params, body }) => store.save(known(WRITE, params.collection), { ...body, id: undefined }));
route('PUT', '/api/:collection/:id', 'any', ({ params, body }) => store.save(known(WRITE, params.collection), { ...body, id: params.id }));
route('DELETE', '/api/:collection/:id', 'any', ({ params }) => store.remove(known(WRITE, params.collection), params.id) && { deleted: true });

// ---------- request handling ----------
async function handleApi(req, res, url, limiter) {
  const match = routes.map((r) => ({ r, m: r.method === req.method && r.re.exec(url.pathname) })).find((x) => x.m);
  if (!match) throw httpError(404, 'Not found.');
  const { r, m } = match;

  if (req.method !== 'GET') {
    // Defence in depth on top of SameSite=Strict cookies.
    const origin = req.headers.origin;
    if (origin && new URL(origin).host !== req.headers.host) throw httpError(403, 'Cross-site requests are not allowed.');
    if (req.headers['x-requested-with'] !== 'fetch') throw httpError(403, 'Missing request header.');
  }
  const user = auth.userFor(parseCookies(req.headers.cookie)[COOKIE]);
  if (r.access !== 'none' && !user) throw httpError(401, 'Please sign in.');
  if (r.access === 'admin' && user.role !== 'admin') throw httpError(403, 'Only administrators can do that.');

  const params = {};
  r.keys.forEach((k, i) => (params[k] = decodeURIComponent(m[i + 1])));
  const body = req.method === 'GET' ? {} : await readBody(req, r.limit);
  const result = r.handler({ req, res, params, body, user, limiter, ip: req.socket.remoteAddress });
  if (!res.headersSent) sendJson(res, 200, await result);
}

function serveStatic(req, res, pathname) {
  if (req.method !== 'GET' && req.method !== 'HEAD') throw httpError(405, 'Method not allowed.');
  let rel;
  try { rel = decodeURIComponent(pathname); } catch { throw httpError(400, 'Bad request.'); }
  if (rel === '/') rel = '/index.html';
  const file = path.normalize(path.join(PUBLIC_DIR, rel));
  if (!file.startsWith(PUBLIC_DIR + path.sep)) throw httpError(403, 'Forbidden.');
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Content-Length': st.size, 'Cache-Control': 'no-cache' });
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(file).pipe(res);
  });
}

function createServer({ dataDir }) {
  fs.mkdirSync(dataDir, { recursive: true });
  store.init(path.join(dataDir, 'library-data.json'));
  auth.init(path.join(dataDir, 'staff.json'));
  const limiter = makeLimiter();

  return http.createServer(async (req, res) => {
    res.setHeader('Content-Security-Policy', CSP);
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Referrer-Policy', 'no-referrer');
    try {
      const url = new URL(req.url, 'http://localhost');
      if (url.pathname.startsWith('/api/')) await handleApi(req, res, url, limiter);
      else serveStatic(req, res, url.pathname);
    } catch (err) {
      const expected = err.status || err.constructor === Error; // plain Errors come from validation rules
      const status = err.status || (expected ? 400 : 500);
      if (status === 500) console.error(err);
      if (res.headersSent) return res.end();
      sendJson(res, status, { error: status === 500 ? 'Something went wrong on the server.' : err.message });
    }
  });
}

module.exports = { createServer };

if (require.main === module) {
  const port = Number(process.env.PORT) || 3000;
  const host = process.env.HOST || '127.0.0.1';
  const dataDir = path.resolve(process.env.DATA_DIR || path.join(__dirname, 'data'));
  createServer({ dataDir }).listen(port, host, () => {
    console.log(`LibraryManagementSystem running at http://${host === '0.0.0.0' ? 'localhost' : host}:${port}`);
    console.log(`Data folder: ${dataDir}`);
    if (auth.needsSetup()) console.log('First run: open the address above to create the administrator account.');
  });
}
