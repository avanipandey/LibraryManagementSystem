// Thin fetch wrapper. Every call resolves to { ok, data } or { ok:false, error }.
(function () {
  async function request(method, url, body) {
    const headers = {};
    if (method !== 'GET') headers['X-Requested-With'] = 'fetch';
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    let res;
    try {
      res = await fetch(url, { method, headers, credentials: 'same-origin', body: body === undefined ? undefined : JSON.stringify(body) });
    } catch {
      return { ok: false, error: 'Cannot reach the server. Check your connection and try again.' };
    }
    let data = null;
    try { data = await res.json(); } catch { /* empty body */ }
    if (res.status === 401 && !url.startsWith('/api/login')) window.dispatchEvent(new Event('unauthorized'));
    if (!res.ok) return { ok: false, error: (data && data.error) || `Request failed (${res.status}).` };
    return { ok: true, data };
  }

  const e = encodeURIComponent;
  window.api = {
    session: () => request('GET', '/api/session'),
    login: (username, password) => request('POST', '/api/login', { username, password }),
    setup: (body) => request('POST', '/api/setup', body),
    logout: () => request('POST', '/api/logout', {}),
    list: (c) => request('GET', `/api/${e(c)}`),
    save: (c, r) => (r.id ? request('PUT', `/api/${e(c)}/${e(r.id)}`, r) : request('POST', `/api/${e(c)}`, r)),
    remove: (c, id) => request('DELETE', `/api/${e(c)}/${e(id)}`),
    returnLoan: (id) => request('POST', `/api/loans/${e(id)}/return`, {}),
    renewLoan: (id) => request('POST', `/api/loans/${e(id)}/renew`, {}),
    settleFine: (id, how) => request('POST', `/api/fines/${e(id)}/settle`, { how }),
    cancelReservation: (id) => request('POST', `/api/reservations/${e(id)}/cancel`, {}),
    stats: () => request('GET', '/api/stats'),
    report: (name) => request('GET', `/api/reports/${e(name)}`),
    getSettings: () => request('GET', '/api/settings'),
    saveSettings: (s) => request('PUT', '/api/settings', s),
    restore: (obj) => request('POST', '/api/restore', obj)
  };
})();
