// LibraryManagementSystem web UI: sign-in, dashboard, CRUD screens, circulation, reports, staff and settings.
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const cap = (s) => s[0].toUpperCase() + s.slice(1);
const addDays = (iso, n) => new Date(Date.parse(iso + 'T00:00:00Z') + n * 86400000).toISOString().slice(0, 10);

const DATA_SETS = ['books', 'sections', 'users', 'loans', 'reservations', 'fines'];
const state = {
  user: null, view: 'dashboard', search: '', report: 'overdue', today: '', settings: {}, stats: null, reportData: null,
  data: { books: [], sections: [], users: [], loans: [], reservations: [], fines: [], staff: [] },
  editing: null, formFields: [], deleting: null, onConfirm: null
};

const money = (n) => `${state.settings.currency || '$'}${Number(n).toFixed(2)}`;
const sectionName = (id) => (state.data.sections.find((s) => s.id === id) || {}).name || 'Unknown';
const bookTitle = (id) => (state.data.books.find((b) => b.id === id) || {}).title || 'Deleted book';
const userName = (id) => (state.data.users.find((u) => u.id === id) || {}).name || 'Deleted member';
const hasReady = (bookId) => state.data.reservations.some((r) => r.bookId === bookId && r.status === 'Ready');
const lendableBooks = () => state.data.books.filter((b) => b.available > 0 || hasReady(b.id));
const activeUsers = () => state.data.users.filter((u) => u.status === 'Active');
const isOpen = (r) => r.status === 'Waiting' || r.status === 'Ready';

const NAV = [
  { group: 'Overview', items: [['dashboard', 'Dashboard']] },
  { group: 'Catalogue', items: [['books', 'Books'], ['sections', 'Sections']] },
  { group: 'Circulation', items: [['loans', 'Loans'], ['reservations', 'Reservations'], ['fines', 'Fines']] },
  { group: 'People', items: [['users', 'Members']] },
  { group: 'Insight', items: [['reports', 'Reports']] },
  { group: 'Admin', admin: true, items: [['staff', 'Staff'], ['settings', 'Settings']] }
];
const COUNTS = {
  books: () => state.data.books.length,
  sections: () => state.data.sections.length,
  users: () => state.data.users.length,
  loans: () => state.data.loans.filter((l) => l.status !== 'Returned').length,
  reservations: () => state.data.reservations.filter(isOpen).length,
  fines: () => state.data.fines.filter((f) => f.status === 'Unpaid').length,
  staff: () => state.data.staff.length
};

const ENTITIES = {
  books: {
    label: 'Books', singular: 'book',
    fields: [
      { key: 'title', label: 'Title', required: true },
      { key: 'author', label: 'Author', required: true },
      { key: 'isbn', label: 'ISBN' },
      { key: 'sectionId', label: 'Section', type: 'section', required: true },
      { key: 'year', label: 'Published year', type: 'number' },
      { key: 'copies', label: 'Copies', type: 'number', required: true, def: 1 }
    ],
    columns: ['title', 'author', 'isbn', 'sectionId', 'available'], labels: { available: 'Available' },
    empty: 'No books yet. Add your first book to start the catalogue.'
  },
  sections: {
    label: 'Sections', singular: 'section',
    fields: [
      { key: 'name', label: 'Name', required: true },
      { key: 'location', label: 'Location (floor / shelf)' },
      { key: 'description', label: 'Description', type: 'textarea' }
    ],
    columns: ['name', 'location', 'description'],
    empty: 'No sections yet. Add a section, then assign books to it.'
  },
  users: {
    label: 'Members', singular: 'member',
    fields: [
      { key: 'name', label: 'Full name', required: true },
      { key: 'email', label: 'Email', type: 'email', required: true },
      { key: 'phone', label: 'Phone' },
      { key: 'role', label: 'Role', type: 'select', options: ['Member', 'Librarian'], def: 'Member' },
      { key: 'status', label: 'Status', type: 'select', options: ['Active', 'Suspended'], def: 'Active' }
    ],
    columns: ['memberNo', 'name', 'email', 'role', 'status', 'onLoan'], labels: { memberNo: 'No.', onLoan: 'Books out' },
    empty: 'No members yet. Add a member or librarian.'
  },
  loans: {
    label: 'Loans', singular: 'loan',
    fields: [
      { key: 'bookId', label: 'Book', type: 'book', required: true },
      { key: 'userId', label: 'Member', type: 'user', required: true },
      { key: 'issuedOn', label: 'Issued on', type: 'date', required: true, def: () => state.today },
      { key: 'dueOn', label: 'Due on', type: 'date', required: true, def: () => addDays(state.today, state.settings.loanDays || 14) }
    ],
    editKeys: ['dueOn'],
    columns: ['bookId', 'userId', 'issuedOn', 'dueOn', 'status', 'fine'], labels: { status: 'Status', fine: 'Fine' },
    empty: 'No loans yet. Lend a book to a member to get started.'
  },
  reservations: {
    label: 'Reservations', singular: 'reservation',
    fields: [
      { key: 'bookId', label: 'Book (no free copies)', type: 'bookFull', required: true },
      { key: 'userId', label: 'Member', type: 'user', required: true }
    ],
    columns: ['bookId', 'userId', 'reservedOn', 'status'], labels: { reservedOn: 'Reserved on', status: 'Status' },
    empty: 'No reservations. Members can queue for books that are fully out on loan.'
  },
  staff: {
    label: 'Staff', singular: 'staff account',
    fields: [
      { key: 'name', label: 'Full name', required: true },
      { key: 'username', label: 'Username', required: true },
      { key: 'role', label: 'Role', type: 'select', options: ['librarian', 'admin'], def: 'librarian' },
      { key: 'password', label: 'Password (8+ characters; leave blank to keep)', type: 'password' }
    ],
    columns: ['name', 'username', 'role'],
    empty: 'No staff accounts.'
  },
  fines: {
    label: 'Fines', singular: 'fine', readOnly: true,
    columns: ['userId', 'bookId', 'dueOn', 'daysLate', 'amount', 'status'],
    labels: { userId: 'Member', bookId: 'Book', dueOn: 'Due on', daysLate: 'Days late', amount: 'Amount', status: 'Status' },
    empty: 'No fines. Fines appear when a book is kept past its due date.'
  }
};

// ---------- plumbing ----------
async function unwrap(res) {
  if (!res.ok) throw new Error(res.error);
  return res.data;
}
const call = async (fn, ...args) => unwrap(await fn(...args));

function toast(message, isError) {
  const t = $('toast');
  t.textContent = message;
  t.className = 'toast' + (isError ? ' error' : '');
  t.hidden = false;
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => (t.hidden = true), 3200);
}

async function refresh() {
  for (const name of DATA_SETS) state.data[name] = await call(window.api.list, name);
  state.settings = await call(window.api.getSettings);
  if (state.user.role === 'admin') state.data.staff = await call(window.api.list, 'staff');
  if (state.view === 'dashboard') state.stats = await call(window.api.stats);
  if (state.view === 'reports') state.reportData = await call(window.api.report, state.report);
}

async function mutate(thunk, message) {
  try {
    const data = await unwrap(await thunk());
    await refresh();
    render();
    toast(typeof message === 'function' ? message(data) : message);
    return data;
  } catch (err) {
    toast(err.message, true);
  }
}

async function go(view) {
  state.view = view;
  state.search = '';
  try { await refresh(); } catch (err) { toast(err.message, true); }
  render();
}

function askConfirm(message, okLabel, onOk) {
  state.onConfirm = onOk;
  $('confirm-text').textContent = message;
  $('confirm-ok').textContent = okLabel;
  $('confirm').returnValue = '';
  $('confirm').showModal();
}

// ---------- rendering ----------
const pill = (label, cls = '') => `<span class="pill ${cls}">${esc(label)}</span>`;
const STATUS = { Active: 'ok', Overdue: 'late', Returned: 'quiet', Waiting: 'warn', Ready: 'ok', Fulfilled: 'quiet', Cancelled: 'quiet', Unpaid: 'late', Accruing: 'warn', Paid: 'ok', Waived: 'quiet', Suspended: 'warn' };
const dash = '<span class="muted">—</span>';

function cell(key, row) {
  switch (key) {
    case 'sectionId': return pill(sectionName(row.sectionId));
    case 'bookId': return esc(bookTitle(row.bookId));
    case 'userId': return esc(userName(row.userId));
    case 'available': return pill(`${row.available} of ${row.copies}`, row.available > 0 ? 'ok' : 'warn');
    case 'status': return pill(row.status, STATUS[row.status] || '');
    case 'role': return pill(row.role);
    case 'fine': return row.fine > 0 ? esc(money(row.fine)) : dash;
    case 'amount': return esc(money(row.amount));
    default: return esc(row[key]) || dash;
  }
}

function rowActions(r) {
  const btn = (act, label, extra = '') => `<button class="btn small ${extra}" data-act="${act}" data-id="${r.id}">${label}</button>`;
  const del = btn('delete', 'Delete', 'danger-text');
  switch (state.view) {
    case 'loans': return r.returnedOn ? del : btn('return', 'Return') + btn('renew', 'Renew') + btn('edit', 'Due date') + del;
    case 'reservations': return (isOpen(r) ? btn('cancelRes', 'Cancel') : '') + del;
    case 'fines': return r.status === 'Unpaid' ? btn('pay', 'Mark paid') + btn('waive', 'Waive') : '';
    default: return btn('edit', 'Edit') + del;
  }
}

function renderNav() {
  $('nav').innerHTML = NAV.filter((g) => !g.admin || state.user.role === 'admin').map((g) => `<p class="nav-group">${g.group}</p>` + g.items.map(([id, label]) => {
    const count = COUNTS[id] ? `<span class="nav-count">${COUNTS[id]()}</span>` : '';
    return `<button class="nav-item ${id === state.view ? 'active' : ''}" data-act="nav" data-view="${id}"><span>${label}</span>${count}</button>`;
  }).join('')).join('');
  $('lib-name').textContent = state.settings.libraryName || '';
  $('user-box').innerHTML = `<span class="user-name">${esc(state.user.name)}<br><span class="muted">${esc(state.user.role)}</span></span><button class="btn small" data-act="logout">Sign out</button>`;
}

function renderEntity() {
  const e = ENTITIES[state.view];
  const label = (k) => e.labels?.[k] || e.fields.find((f) => f.key === k).label.replace(/ \(.*\)/, '');
  $('view').innerHTML = `
    <header class="toolbar">
      <h2>${e.label}</h2>
      <input id="search" type="search" placeholder="Search ${e.label.toLowerCase()}" value="${esc(state.search)}" aria-label="Search">
      ${e.readOnly ? '' : `<button class="btn primary" data-act="add">Add ${e.singular}</button>`}
    </header>
    <div class="table-wrap">
      <table>
        <thead><tr>${e.columns.map((k) => `<th>${esc(label(k))}</th>`).join('')}<th></th></tr></thead>
        <tbody id="tbody"></tbody>
      </table>
      <p id="empty" class="empty" hidden></p>
    </div>`;
  fillRows();
}

function textFor(key, row) {
  if (key === 'sectionId') return sectionName(row.sectionId);
  if (key === 'bookId') return bookTitle(row.bookId);
  if (key === 'userId') return userName(row.userId);
  return row[key];
}

function fillRows() {
  const e = ENTITIES[state.view];
  const q = state.search.trim().toLowerCase();
  const all = state.data[state.view];
  const rows = all.filter((r) => !q || e.columns.some((k) => String(textFor(k, r) ?? '').toLowerCase().includes(q)));
  $('tbody').innerHTML = rows.map((r) =>
    `<tr>${e.columns.map((k) => `<td>${cell(k, r)}</td>`).join('')}<td class="row-actions">${rowActions(r)}</td></tr>`).join('');
  $('empty').hidden = rows.length > 0;
  $('empty').textContent = all.length === 0 ? e.empty : `Nothing matches “${state.search}”.`;
}

function renderDashboard() {
  const s = state.stats;
  const card = (label, value, cls = '') => `<div class="card ${cls}"><div class="card-value">${value}</div><div class="card-label">${label}</div></div>`;
  const list = (items, fn, none) => items.length ? `<ul class="rows">${items.map(fn).join('')}</ul>` : `<p class="muted">${none}</p>`;
  $('view').innerHTML = `
    <header class="toolbar">
      <h2>Dashboard</h2>
      <button class="btn" data-act="quick" data-view="books">Add book</button>
      <button class="btn" data-act="quick" data-view="users">Add member</button>
      <button class="btn primary" data-act="quick" data-view="loans">Lend a book</button>
    </header>
    <div class="scroll">
      <div class="cards">
        ${card('Titles', s.titles)}${card('Copies', s.copies)}${card('On loan', s.onLoan, 'accent')}
        ${card('Due today', s.dueToday)}${card('Overdue', s.overdue, s.overdue ? 'alert' : '')}
        ${card('Reservations', s.reservations)}${card('Members', s.members)}${card('Unpaid fines', esc(money(s.unpaidFines)), s.unpaidFines ? 'alert' : '')}
      </div>
      <div class="panels">
        <section class="panel"><h3>Overdue loans</h3>
          ${list(s.overdueList, (o) => `<li><span>${esc(o.book)}<br><span class="muted">${esc(o.member)}</span></span>${pill(`${o.daysLate} day${o.daysLate === 1 ? '' : 's'} late`, 'late')}</li>`, 'Nothing is overdue.')}
        </section>
        <section class="panel"><h3>Most borrowed</h3>
          ${list(s.popular, (p) => `<li><span>${esc(p.title)}<br><span class="muted">${esc(p.author)}</span></span>${pill(`${p.count}×`)}</li>`, 'No loans recorded yet.')}
        </section>
        <section class="panel wide"><h3>Recent activity</h3>
          ${list(s.recent, (a) => `<li><span>${esc(a.text)}</span><span class="when">${esc(new Date(a.at).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' }))}</span></li>`, 'Activity will appear here.')}
        </section>
      </div>
    </div>`;
}

const REPORTS = [['overdue', 'Overdue loans'], ['popular', 'Most borrowed'], ['inventory', 'Inventory by section'], ['members', 'Member activity'], ['fines', 'Fines']];

function renderReports() {
  const r = state.reportData;
  $('view').innerHTML = `
    <header class="toolbar"><h2>Reports</h2><button class="btn primary" data-act="exportReport">Export CSV</button></header>
    <div class="tabs">${REPORTS.map(([id, label]) => `<button class="tab ${id === state.report ? 'active' : ''}" data-act="report" data-name="${id}">${label}</button>`).join('')}</div>
    <div class="table-wrap"><table>
      <thead><tr>${r.columns.map((c) => `<th>${esc(c)}</th>`).join('')}</tr></thead>
      <tbody>${r.rows.map((row) => `<tr>${row.map((v) => `<td>${esc(v)}</td>`).join('')}</tr>`).join('')}</tbody>
    </table>${r.rows.length ? '' : '<p class="empty">Nothing to report yet.</p>'}</div>`;
}

const SETTING_FIELDS = [
  ['libraryName', 'Library name', 'text', ''], ['currency', 'Currency symbol', 'text', ''],
  ['loanDays', 'Loan period (days)', 'number', 'min="1" step="1"'], ['maxLoans', 'Max books per member', 'number', 'min="1" step="1"'],
  ['maxRenewals', 'Max renewals per loan', 'number', 'min="0" step="1"'], ['finePerDay', 'Fine per overdue day', 'number', 'min="0" step="0.01"']
];

function renderSettings() {
  const s = state.settings;
  $('view').innerHTML = `
    <header class="toolbar"><h2>Settings</h2></header>
    <div class="scroll"><div class="settings">
      <form id="settings-form" class="panel" novalidate>
        <h3>Library rules</h3>
        <div class="grid2">${SETTING_FIELDS.map(([k, label, type, attrs]) =>
          `<div class="field"><label for="s-${k}">${label}</label><input id="s-${k}" type="${type}" ${attrs} value="${esc(s[k])}"></div>`).join('')}</div>
        <label class="check"><input id="s-blockOnFines" type="checkbox" ${s.blockOnFines ? 'checked' : ''}> Block lending to members with unpaid fines</label>
        <p id="settings-error" class="form-error" role="alert" hidden></p>
        <div class="btn-row"><button type="submit" class="btn primary">Save settings</button></div>
      </form>
      <section class="panel">
        <h3>Backup and restore</h3>
        <p class="muted">Save a copy of all books, members, loans and settings, or load one back. Restoring replaces current data.</p>
        <div class="btn-row"><button class="btn" data-act="backup">Back up data</button><button class="btn" data-act="restore">Restore from backup</button></div>
      </section>
    </div></div>`;
}

function render() {
  renderNav();
  if (state.view === 'dashboard') return renderDashboard();
  if (state.view === 'reports') return renderReports();
  if (state.view === 'settings') return renderSettings();
  renderEntity();
}

// ---------- forms ----------
function fieldHtml(f, value) {
  const id = 'f-' + f.key;
  const req = f.required ? 'required' : '';
  let input;
  if (['section', 'book', 'bookFull', 'user', 'select'].includes(f.type)) {
    const opts = {
      section: () => state.data.sections.map((s) => [s.id, s.name]),
      book: () => lendableBooks().map((b) => [b.id, b.available > 0 ? `${b.title} (${b.available} available)` : `${b.title} (reserved copy)`]),
      bookFull: () => state.data.books.filter((b) => b.available === 0).map((b) => [b.id, b.title]),
      user: () => activeUsers().map((u) => [u.id, `${u.name} (${u.memberNo})`]),
      select: () => f.options.map((o) => [o, o])
    }[f.type]();
    const ph = { section: 'Choose a section', book: 'Choose a book', bookFull: 'Choose a book', user: 'Choose a member' }[f.type];
    input = `<select id="${id}" ${req}>${ph ? `<option value="">${ph}</option>` : ''}${opts.map(([v, l]) =>
      `<option value="${esc(v)}" ${v === value ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select>`;
  } else if (f.type === 'textarea') {
    input = `<textarea id="${id}">${esc(value)}</textarea>`;
  } else {
    input = `<input id="${id}" type="${f.type || 'text'}" value="${esc(value)}" ${req} ${f.type === 'number' ? 'min="0" step="1"' : ''} ${f.type === 'password' ? 'autocomplete="new-password"' : ''}>`;
  }
  return `<div class="field"><label for="${id}">${esc(f.label)}${f.required ? ' <span class="req">*</span>' : ''}</label>${input}</div>`;
}

function openForm(record) {
  const e = ENTITIES[state.view];
  state.editing = record || null;
  state.formFields = record && e.editKeys ? e.fields.filter((f) => e.editKeys.includes(f.key)) : e.fields;
  const initial = (f) => (record ? record[f.key] : typeof f.def === 'function' ? f.def() : f.def ?? '');
  $('dialog-title').textContent = `${record ? 'Edit' : 'Add'} ${e.singular}`;
  $('fields').innerHTML = state.formFields.map((f) => fieldHtml(f, initial(f))).join('');
  $('form-error').hidden = true;
  $('dialog').showModal();
  $('fields').querySelector('input, select, textarea').focus();
}

function addRecord() {
  const v = state.view;
  if (v === 'books' && !state.data.sections.length) return toast('Add a section first. Every book belongs to a section.', true);
  if (v === 'loans') {
    if (!lendableBooks().length) return toast('No books are available to lend right now.', true);
    if (!activeUsers().length) return toast('Add an active member first.', true);
  }
  if (v === 'reservations') {
    if (!state.data.books.some((b) => b.available === 0)) return toast('Every book has free copies. Lend it directly instead.', true);
    if (!activeUsers().length) return toast('Add an active member first.', true);
  }
  openForm(null);
}

// ---------- events ----------
const find = (id) => state.data[state.view].find((r) => r.id === id);

const ACTIONS = {
  nav: ({ view }) => go(view),
  quick: ({ view }) => go(view).then(addRecord),
  add: () => addRecord(),
  edit: ({ id }) => openForm(find(id)),
  delete: ({ id }) => {
    const rec = find(id);
    const label = state.view === 'loans' ? `the loan of “${bookTitle(rec.bookId)}” to ${userName(rec.userId)}`
      : state.view === 'reservations' ? `the reservation of “${bookTitle(rec.bookId)}” for ${userName(rec.userId)}`
      : `“${rec.title || rec.name}”`;
    askConfirm(`Delete ${label}? This can't be undone.`, 'Delete', () => mutate(() => window.api.remove(state.view, id), `${cap(ENTITIES[state.view].singular)} deleted`));
  },
  return: ({ id }) => mutate(() => window.api.returnLoan(id), (l) => (l.fineAmount > 0 ? `Returned. Fine of ${money(l.fineAmount)} recorded.` : 'Book marked as returned')),
  renew: ({ id }) => mutate(() => window.api.renewLoan(id), (l) => `Renewed until ${l.dueOn}`),
  cancelRes: ({ id }) => mutate(() => window.api.cancelReservation(id), 'Reservation cancelled'),
  pay: ({ id }) => mutate(() => window.api.settleFine(id, 'Paid'), 'Fine marked as paid'),
  waive: ({ id }) => askConfirm('Waive this fine? The member will no longer owe it.', 'Waive', () => mutate(() => window.api.settleFine(id, 'Waived'), 'Fine waived')),
  report: async ({ name }) => { state.report = name; try { state.reportData = await call(window.api.report, name); } catch (err) { toast(err.message, true); } render(); },
  exportReport: () => { location.href = `/api/reports/${encodeURIComponent(state.report)}/csv`; },
  backup: () => { location.href = '/api/backup'; },
  restore: () => askConfirm('Restore from a backup file? This replaces all current data.', 'Choose file', () => $('restore-file').click()),
  logout: async () => { await window.api.logout(); showAuth('login'); }
};

document.addEventListener('click', (ev) => {
  const el = ev.target.closest('[data-act]');
  if (el && ACTIONS[el.dataset.act]) ACTIONS[el.dataset.act](el.dataset);
});

document.addEventListener('input', (ev) => {
  if (ev.target.id === 'search') { state.search = ev.target.value; fillRows(); }
});

$('cancel').addEventListener('click', () => $('dialog').close());

$('form').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const record = state.editing ? { id: state.editing.id } : {};
  for (const f of state.formFields) record[f.key] = $('f-' + f.key).value;
  try {
    await call(window.api.save, state.view, record);
    await refresh();
    $('dialog').close();
    render();
    toast(`${cap(ENTITIES[state.view].singular)} saved`);
  } catch (err) {
    $('form-error').textContent = err.message;
    $('form-error').hidden = false;
  }
});

document.addEventListener('submit', async (ev) => {
  if (ev.target.id !== 'settings-form') return;
  ev.preventDefault();
  const next = { blockOnFines: $('s-blockOnFines').checked };
  for (const [k] of SETTING_FIELDS) next[k] = $('s-' + k).value;
  try {
    await call(window.api.saveSettings, next);
    await refresh();
    render();
    toast('Settings saved');
  } catch (err) {
    $('settings-error').textContent = err.message;
    $('settings-error').hidden = false;
  }
});

$('confirm').addEventListener('close', () => {
  if ($('confirm').returnValue === 'ok' && state.onConfirm) {
    const run = state.onConfirm;
    state.onConfirm = null;
    run();
  }
});

// ---------- sign-in, setup and start-up ----------
function showAuth(mode, libraryName) {
  state.user = null;
  state.onConfirm = null;
  $('app').hidden = true;
  $('auth').hidden = false;
  const setup = mode === 'setup';
  const field = (id, label, type, extra = '') => `<div class="field"><label for="${id}">${label}</label><input id="${id}" type="${type}" ${extra}></div>`;
  $('auth').dataset.mode = mode;
  $('auth-title').textContent = setup ? 'Welcome! Create the administrator account' : 'Sign in';
  $('auth-sub').textContent = setup ? 'This account manages settings, staff and backups.' : (libraryName || state.settings.libraryName || 'Library staff sign-in');
  $('auth-fields').innerHTML = (setup ? field('a-name', 'Your name', 'text', 'autocomplete="name"') : '') +
    field('a-username', 'Username', 'text', 'autocomplete="username" autocapitalize="none"') +
    field('a-password', setup ? 'Password (8+ characters)' : 'Password', 'password', `autocomplete="${setup ? 'new-password' : 'current-password'}"`);
  $('auth-submit').textContent = setup ? 'Create account and continue' : 'Sign in';
  $('auth-error').hidden = true;
  $('a-' + (setup ? 'name' : 'username')).focus();
}

function startApp() {
  $('auth').hidden = true;
  $('app').hidden = false;
  go('dashboard');
}

$('auth-form').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const setup = $('auth').dataset.mode === 'setup';
  const username = $('a-username').value;
  const password = $('a-password').value;
  const res = setup ? await window.api.setup({ name: $('a-name').value, username, password }) : await window.api.login(username, password);
  if (!res.ok) {
    $('auth-error').textContent = res.error;
    $('auth-error').hidden = false;
    return;
  }
  state.user = res.data.user;
  state.today = res.data.today;
  startApp();
});

window.addEventListener('unauthorized', () => {
  if (!state.user) return;
  showAuth('login');
  toast('Your session has ended. Please sign in again.', true);
});

$('restore-file').addEventListener('change', async (ev) => {
  const file = ev.target.files[0];
  ev.target.value = '';
  if (!file) return;
  let obj;
  try { obj = JSON.parse(await file.text()); } catch { return toast('That file is not a valid backup.', true); }
  const res = await window.api.restore(obj);
  if (!res.ok) return toast(res.error, true);
  await refresh();
  render();
  toast('Backup restored');
});

(async function boot() {
  const res = await window.api.session();
  if (!res.ok) { showAuth('login'); $('auth-error').textContent = res.error; $('auth-error').hidden = false; return; }
  const info = res.data;
  state.today = info.today;
  if (info.setupRequired) return showAuth('setup', info.libraryName);
  if (!info.user) return showAuth('login', info.libraryName);
  state.user = info.user;
  startApp();
})();
