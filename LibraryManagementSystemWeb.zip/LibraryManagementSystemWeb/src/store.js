// JSON-file datastore + business rules for the library suite.
// No native modules, so `npm install` works everywhere.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DEFAULTS = { libraryName: 'City Library', currency: '$', loanDays: 14, maxLoans: 5, maxRenewals: 2, finePerDay: 1, blockOnFines: true };
const COLLECTIONS = ['books', 'sections', 'users', 'loans', 'reservations'];
const emptyDb = () => ({ books: [], sections: [], users: [], loans: [], reservations: [], log: [], settings: { ...DEFAULTS } });

let file = null;
let db = emptyDb();

// ---------- small helpers ----------
const uid = () => crypto.randomUUID();
const text = (v) => (v == null ? '' : String(v).trim());
const pad = (n) => String(n).padStart(2, '0');
const today = () => { const d = new Date(); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; };
const isDate = (v) => /^\d{4}-\d{2}-\d{2}$/.test(v) && !Number.isNaN(Date.parse(v));
const dayNum = (iso) => Math.round(Date.parse(iso + 'T00:00:00Z') / 86400000);
const daysBetween = (a, b) => dayNum(b) - dayNum(a);
const addDays = (iso, n) => new Date((dayNum(iso) + n) * 86400000).toISOString().slice(0, 10);
const round2 = (n) => Math.round(n * 100) / 100;
const money = (n) => `${db.settings.currency}${Number(n).toFixed(2)}`;
const SINGULAR = { books: 'book', sections: 'section', users: 'member', loans: 'loan', reservations: 'reservation' };

const book = (id) => db.books.find((b) => b.id === id);
const user = (id) => db.users.find((u) => u.id === id);
const bookTitle = (id) => (book(id) || {}).title || 'Deleted book';
const userName = (id) => (user(id) || {}).name || 'Deleted user';
const nextMemberNo = () => 'M' + String(db.users.reduce((m, u) => Math.max(m, parseInt((u.memberNo || '').slice(1), 10) || 0), 0) + 1).padStart(4, '0');

function note(message) {
  db.log.unshift({ at: new Date().toISOString(), text: message });
  db.log.length = Math.min(db.log.length, 200);
}

// ---------- persistence ----------
function load(obj) {
  db = { ...emptyDb(), ...obj, settings: { ...DEFAULTS, ...(obj.settings || {}) } };
  for (const c of [...COLLECTIONS, 'log']) if (!Array.isArray(db[c])) db[c] = [];
  db.users.forEach((u) => { if (!u.memberNo) u.memberNo = nextMemberNo(); });
}

function init(filePath) {
  file = filePath;
  fs.mkdirSync(path.dirname(file), { recursive: true });
  if (fs.existsSync(file)) {
    load(JSON.parse(fs.readFileSync(file, 'utf8')));
  } else {
    db = emptyDb();
    const now = new Date().toISOString();
    db.sections = ['Fiction', 'Science', 'History'].map((name, i) => ({
      id: uid(), name, location: `Floor 1, Shelf ${i + 1}`, description: '', createdAt: now
    }));
    persist();
  }
}

function persist() {
  const tmp = file + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
  fs.renameSync(tmp, file);
}

const dump = () => JSON.parse(JSON.stringify(db));

function restore(obj) {
  if (!obj || !Array.isArray(obj.books) || !Array.isArray(obj.users) || !Array.isArray(obj.sections)) {
    throw new Error('This file is not a LibraryManagementSystem backup.');
  }
  load(obj);
  note('Data restored from a backup');
  persist();
  return true;
}

// ---------- derived values ----------
const loansOut = (bookId) => db.loans.filter((l) => l.bookId === bookId && !l.returnedOn).length;
const readyFor = (bookId) => db.reservations.filter((r) => r.bookId === bookId && r.status === 'Ready');
const available = (b) => Math.max(0, b.copies - loansOut(b.id) - readyFor(b.id).length);
const openCount = (userId) => db.loans.filter((l) => l.userId === userId && !l.returnedOn).length;
const loanStatus = (l) => (l.returnedOn ? 'Returned' : l.dueOn < today() ? 'Overdue' : 'Active');

function fineOf(l) {
  if (l.returnedOn && l.fineAmount != null) return { daysLate: l.daysLate, amount: l.fineAmount };
  const end = l.returnedOn || today();
  const daysLate = Math.max(0, daysBetween(l.dueOn, end));
  return { daysLate, amount: round2(daysLate * db.settings.finePerDay) };
}
const fineState = (l) => {
  if (fineOf(l).amount <= 0) return '';
  return l.returnedOn ? l.fineStatus || 'Unpaid' : 'Accruing';
};
const unpaidFines = (userId) =>
  round2(db.loans.filter((l) => l.userId === userId && l.returnedOn && !l.fineStatus).reduce((s, l) => s + fineOf(l).amount, 0));

function fineRows() {
  return db.loans.filter((l) => fineState(l)).map((l) => {
    const f = fineOf(l);
    return { id: l.id, userId: l.userId, bookId: l.bookId, dueOn: l.dueOn, returnedOn: l.returnedOn || '', daysLate: f.daysLate, amount: f.amount, status: fineState(l) };
  }).sort((a, b) => b.dueOn.localeCompare(a.dueOn));
}

// Hand freed copies to the members waiting longest.
function promote(bookId) {
  const b = book(bookId);
  if (!b) return;
  let free = b.copies - loansOut(bookId) - readyFor(bookId).length;
  const waiting = db.reservations.filter((r) => r.bookId === bookId && r.status === 'Waiting');
  while (free > 0 && waiting.length) {
    const r = waiting.shift();
    r.status = 'Ready';
    r.readyOn = today();
    free--;
    note(`“${b.title}” is ready for ${userName(r.userId)}`);
  }
}

// ---------- validation ----------
function checkCol(collection) {
  if (!COLLECTIONS.includes(collection)) throw new Error('Unknown collection: ' + collection);
}

function clean(collection, r) {
  if (collection === 'sections') {
    const out = { name: text(r.name), location: text(r.location), description: text(r.description) };
    if (!out.name) throw new Error('Section name is required.');
    return out;
  }
  if (collection === 'books') {
    const out = {
      title: text(r.title), author: text(r.author), isbn: text(r.isbn), sectionId: text(r.sectionId),
      year: r.year === '' || r.year == null ? '' : Number(r.year), copies: Number(r.copies)
    };
    if (!out.title) throw new Error('Book title is required.');
    if (!out.author) throw new Error('Author is required.');
    if (!out.sectionId || !db.sections.some((s) => s.id === out.sectionId)) throw new Error('Choose a section for this book.');
    if (!Number.isInteger(out.copies) || out.copies < 1) throw new Error('Copies must be a whole number of 1 or more.');
    if (out.year !== '' && (!Number.isInteger(out.year) || out.year < 0 || out.year > 2100)) throw new Error('Enter a valid year.');
    return out;
  }
  const out = {
    name: text(r.name), email: text(r.email).toLowerCase(), phone: text(r.phone),
    role: r.role === 'Librarian' ? 'Librarian' : 'Member',
    status: r.status === 'Suspended' ? 'Suspended' : 'Active'
  };
  if (!out.name) throw new Error('Name is required.');
  if (!/^\S+@\S+\.\S+$/.test(out.email)) throw new Error('Enter a valid email address.');
  return out;
}

function checkUnique(collection, id, out) {
  const others = db[collection].filter((x) => x.id !== id);
  const same = (a, b) => a && b && a.toLowerCase() === b.toLowerCase();
  if (collection === 'sections' && others.some((x) => same(x.name, out.name))) throw new Error('A section with this name already exists.');
  if (collection === 'books' && out.isbn && others.some((x) => same(x.isbn, out.isbn))) throw new Error('A book with this ISBN already exists.');
  if (collection === 'users' && others.some((x) => same(x.email, out.email))) throw new Error('A member with this email already exists.');
}

// ---------- reading ----------
function list(collection) {
  if (collection === 'fines') return fineRows();
  checkCol(collection);
  if (collection === 'books') return db.books.map((b) => ({ ...b, available: available(b) }));
  if (collection === 'users') return db.users.map((u) => ({ ...u, onLoan: openCount(u.id), unpaidFines: unpaidFines(u.id) }));
  if (collection === 'loans') return db.loans.map((l) => ({ ...l, status: loanStatus(l), fine: fineOf(l).amount }));
  return db[collection];
}

// ---------- writing ----------
function createLoan(r) {
  const out = { bookId: text(r.bookId), userId: text(r.userId), issuedOn: text(r.issuedOn), dueOn: text(r.dueOn) };
  const b = book(out.bookId);
  const u = user(out.userId);
  const s = db.settings;
  if (!b) throw new Error('Choose a book to lend.');
  if (!u) throw new Error('Choose a member for this loan.');
  if (!isDate(out.issuedOn)) throw new Error('Enter a valid issue date.');
  if (!isDate(out.dueOn)) throw new Error('Enter a valid due date.');
  if (out.dueOn < out.issuedOn) throw new Error("The due date can't be before the issue date.");
  if (u.status !== 'Active') throw new Error(`${u.name} is suspended and can't borrow books.`);
  if (!readyFor(b.id).some((x) => x.userId === u.id) && available(b) < 1) throw new Error(`No copies of “${b.title}” are available right now.`);
  if (db.loans.some((l) => !l.returnedOn && l.bookId === b.id && l.userId === u.id)) throw new Error(`${u.name} already has this book.`);
  if (openCount(u.id) >= s.maxLoans) throw new Error(`${u.name} has reached the limit of ${s.maxLoans} books.`);
  if (s.blockOnFines && unpaidFines(u.id) > 0) throw new Error(`${u.name} has unpaid fines of ${money(unpaidFines(u.id))}. Settle them first.`);

  db.reservations.filter((x) => x.bookId === b.id && x.userId === u.id && ['Waiting', 'Ready'].includes(x.status))
    .forEach((x) => { x.status = 'Fulfilled'; x.fulfilledOn = today(); });
  const loan = { id: uid(), ...out, renewals: 0, createdAt: new Date().toISOString() };
  db.loans.push(loan);
  note(`Lent “${b.title}” to ${u.name}`);
  persist();
  return loan;
}

function changeDueDate(loan, r) {
  const dueOn = text(r.dueOn);
  if (loan.returnedOn) throw new Error("A returned loan can't be changed.");
  if (!isDate(dueOn)) throw new Error('Enter a valid due date.');
  if (dueOn < loan.issuedOn) throw new Error("The due date can't be before the issue date.");
  loan.dueOn = dueOn;
  loan.updatedAt = new Date().toISOString();
  note(`Changed due date of “${bookTitle(loan.bookId)}” (${userName(loan.userId)}) to ${dueOn}`);
  persist();
  return loan;
}

function createReservation(r) {
  const b = book(text(r.bookId));
  const u = user(text(r.userId));
  if (!b) throw new Error('Choose a book to reserve.');
  if (!u) throw new Error('Choose a member for this reservation.');
  if (u.status !== 'Active') throw new Error(`${u.name} is suspended and can't reserve books.`);
  if (available(b) > 0) throw new Error(`Copies of “${b.title}” are available. Lend it directly.`);
  if (db.loans.some((l) => !l.returnedOn && l.bookId === b.id && l.userId === u.id)) throw new Error(`${u.name} already has this book.`);
  if (db.reservations.some((x) => x.bookId === b.id && x.userId === u.id && ['Waiting', 'Ready'].includes(x.status))) {
    throw new Error(`${u.name} has already reserved this book.`);
  }
  const res = { id: uid(), bookId: b.id, userId: u.id, reservedOn: today(), status: 'Waiting', createdAt: new Date().toISOString() };
  db.reservations.push(res);
  note(`${u.name} reserved “${b.title}”`);
  persist();
  return res;
}

function save(collection, record) {
  checkCol(collection);
  record = record || {};
  const existing = record.id ? db[collection].find((x) => x.id === record.id) : null;
  if (record.id && !existing) throw new Error('This record no longer exists.');
  if (collection === 'reservations') {
    if (existing) throw new Error("Reservations can't be edited. Cancel it and make a new one.");
    return createReservation(record);
  }
  if (collection === 'loans') return existing ? changeDueDate(existing, record) : createLoan(record);

  const out = clean(collection, record);
  checkUnique(collection, existing && existing.id, out);
  if (collection === 'books' && existing && out.copies < loansOut(existing.id)) {
    throw new Error(`${loansOut(existing.id)} copies are on loan. Copies can't go below that.`);
  }
  let result;
  if (existing) {
    result = Object.assign(existing, out, { updatedAt: new Date().toISOString() });
  } else {
    result = { id: uid(), ...out, createdAt: new Date().toISOString() };
    if (collection === 'users') result.memberNo = nextMemberNo();
    db[collection].push(result);
  }
  note(`${existing ? 'Updated' : 'Added'} ${SINGULAR[collection]} “${result.title || result.name}”`);
  if (collection === 'books') promote(result.id);
  persist();
  return result;
}

function remove(collection, id) {
  checkCol(collection);
  const rec = db[collection].find((x) => x.id === id);
  if (!rec) throw new Error('This record no longer exists.');
  if (collection === 'sections') {
    const n = db.books.filter((b) => b.sectionId === id).length;
    if (n > 0) throw new Error(`This section still has ${n} book${n === 1 ? '' : 's'}. Move or delete them first.`);
  }
  if (collection === 'books') {
    if (loansOut(id) > 0) throw new Error('This book is on loan. Mark it returned before deleting.');
    db.reservations = db.reservations.filter((r) => r.bookId !== id);
  }
  if (collection === 'users') {
    if (openCount(id) > 0) throw new Error('This member still has books on loan. Mark them returned first.');
    db.reservations = db.reservations.filter((r) => r.userId !== id);
  }
  db[collection] = db[collection].filter((x) => x.id !== id);
  if (collection === 'loans' || collection === 'reservations') promote(rec.bookId);
  note(`Deleted ${SINGULAR[collection]} “${rec.title || rec.name || (collection === 'loans' ? bookTitle(rec.bookId) : userName(rec.userId))}”`);
  persist();
  return true;
}

function returnLoan(id) {
  const loan = db.loans.find((l) => l.id === id);
  if (!loan) throw new Error('This loan no longer exists.');
  if (loan.returnedOn) throw new Error('This loan is already returned.');
  loan.returnedOn = today();
  const f = fineOf({ ...loan, returnedOn: undefined });
  loan.daysLate = f.daysLate;
  loan.fineAmount = f.amount;
  loan.updatedAt = new Date().toISOString();
  note(`“${bookTitle(loan.bookId)}” returned by ${userName(loan.userId)}${f.amount > 0 ? ` (fine ${money(f.amount)})` : ''}`);
  promote(loan.bookId);
  persist();
  return { ...loan, fineAmount: f.amount };
}

function renewLoan(id) {
  const loan = db.loans.find((l) => l.id === id);
  if (!loan) throw new Error('This loan no longer exists.');
  if (loan.returnedOn) throw new Error('This loan is already returned.');
  if (loan.dueOn < today()) throw new Error('Overdue loans must be returned, not renewed.');
  if ((loan.renewals || 0) >= db.settings.maxRenewals) throw new Error(`Maximum of ${db.settings.maxRenewals} renewals reached.`);
  if (db.reservations.some((r) => r.bookId === loan.bookId && ['Waiting', 'Ready'].includes(r.status))) {
    throw new Error('Another member is waiting for this book, so it can\'t be renewed.');
  }
  loan.dueOn = addDays(loan.dueOn, db.settings.loanDays);
  loan.renewals = (loan.renewals || 0) + 1;
  note(`Renewed “${bookTitle(loan.bookId)}” for ${userName(loan.userId)} until ${loan.dueOn}`);
  persist();
  return loan;
}

function settleFine(id, how) {
  const loan = db.loans.find((l) => l.id === id);
  if (!loan) throw new Error('This loan no longer exists.');
  if (!loan.returnedOn) throw new Error('A fine can be settled once the book is returned.');
  if (fineOf(loan).amount <= 0) throw new Error('There is no fine on this loan.');
  if (loan.fineStatus) throw new Error(`This fine is already ${loan.fineStatus.toLowerCase()}.`);
  if (!['Paid', 'Waived'].includes(how)) throw new Error('Choose paid or waived.');
  loan.fineStatus = how;
  loan.fineSettledOn = today();
  note(`Fine of ${money(fineOf(loan).amount)} for ${userName(loan.userId)} ${how.toLowerCase()}`);
  persist();
  return loan;
}

function cancelReservation(id) {
  const r = db.reservations.find((x) => x.id === id);
  if (!r) throw new Error('This reservation no longer exists.');
  if (!['Waiting', 'Ready'].includes(r.status)) throw new Error(`This reservation is already ${r.status.toLowerCase()}.`);
  r.status = 'Cancelled';
  note(`${userName(r.userId)} cancelled the reservation for “${bookTitle(r.bookId)}”`);
  promote(r.bookId);
  persist();
  return r;
}

// ---------- settings ----------
const getSettings = () => ({ ...db.settings });

function saveSettings(s) {
  const int = (v, min, max, label) => {
    const n = Number(v);
    if (!Number.isInteger(n) || n < min || n > max) throw new Error(`${label} must be a whole number from ${min} to ${max}.`);
    return n;
  };
  const fine = Number(s.finePerDay);
  if (!(fine >= 0) || fine > 10000) throw new Error('Fine per day must be zero or more.');
  const next = {
    libraryName: text(s.libraryName), currency: text(s.currency).slice(0, 3),
    loanDays: int(s.loanDays, 1, 365, 'Loan period'), maxLoans: int(s.maxLoans, 1, 100, 'Max books per member'),
    maxRenewals: int(s.maxRenewals, 0, 20, 'Max renewals'), finePerDay: round2(fine),
    blockOnFines: s.blockOnFines === true || s.blockOnFines === 'true'
  };
  if (!next.libraryName) throw new Error('Library name is required.');
  if (!next.currency) throw new Error('Currency symbol is required.');
  db.settings = next;
  note('Settings updated');
  persist();
  return getSettings();
}

// ---------- dashboard & reports ----------
function stats() {
  const t = today();
  const open = db.loans.filter((l) => !l.returnedOn);
  const overdue = open.filter((l) => l.dueOn < t).sort((a, b) => a.dueOn.localeCompare(b.dueOn));
  const counts = {};
  db.loans.forEach((l) => { counts[l.bookId] = (counts[l.bookId] || 0) + 1; });
  return {
    titles: db.books.length,
    copies: db.books.reduce((s, b) => s + b.copies, 0),
    onLoan: open.length,
    overdue: overdue.length,
    dueToday: open.filter((l) => l.dueOn === t).length,
    members: db.users.length,
    activeMembers: db.users.filter((u) => u.status === 'Active').length,
    reservations: db.reservations.filter((r) => ['Waiting', 'Ready'].includes(r.status)).length,
    unpaidFines: round2(db.users.reduce((s, u) => s + unpaidFines(u.id), 0)),
    overdueList: overdue.slice(0, 6).map((l) => ({ book: bookTitle(l.bookId), member: userName(l.userId), daysLate: fineOf(l).daysLate })),
    popular: Object.entries(counts).filter(([id]) => book(id)).sort((a, b) => b[1] - a[1]).slice(0, 5)
      .map(([id, n]) => ({ title: book(id).title, author: book(id).author, count: n })),
    recent: db.log.slice(0, 8)
  };
}

function report(name) {
  if (name === 'overdue') {
    const rows = db.loans.filter((l) => loanStatus(l) === 'Overdue').sort((a, b) => a.dueOn.localeCompare(b.dueOn))
      .map((l) => [bookTitle(l.bookId), userName(l.userId), l.dueOn, fineOf(l).daysLate, money(fineOf(l).amount)]);
    return { title: 'Overdue loans', columns: ['Book', 'Member', 'Due on', 'Days late', 'Fine so far'], rows };
  }
  if (name === 'popular') {
    const counts = {};
    db.loans.forEach((l) => { counts[l.bookId] = (counts[l.bookId] || 0) + 1; });
    const rows = db.books.map((b) => [b.title, b.author, counts[b.id] || 0]).sort((a, b) => b[2] - a[2] || a[0].localeCompare(b[0]));
    return { title: 'Most borrowed books', columns: ['Title', 'Author', 'Times borrowed'], rows };
  }
  if (name === 'inventory') {
    const rows = db.sections.map((s) => {
      const bs = db.books.filter((b) => b.sectionId === s.id);
      const copies = bs.reduce((n, b) => n + b.copies, 0);
      const out = bs.reduce((n, b) => n + loansOut(b.id), 0);
      return [s.name, bs.length, copies, out, copies - out];
    });
    return { title: 'Inventory by section', columns: ['Section', 'Titles', 'Copies', 'On loan', 'On shelf'], rows };
  }
  if (name === 'members') {
    const rows = db.users.map((u) => [u.memberNo, u.name, u.status, openCount(u.id), db.loans.filter((l) => l.userId === u.id).length, money(unpaidFines(u.id))]);
    return { title: 'Member activity', columns: ['No.', 'Name', 'Status', 'Books out', 'Total borrowed', 'Unpaid fines'], rows };
  }
  if (name === 'fines') {
    const rows = fineRows().map((f) => [userName(f.userId), bookTitle(f.bookId), f.dueOn, f.daysLate, money(f.amount), f.status]);
    return { title: 'Fines', columns: ['Member', 'Book', 'Due on', 'Days late', 'Amount', 'Status'], rows };
  }
  throw new Error('Unknown report.');
}

function reportCsv(name) {
  const r = report(name);
  const q = (v) => `"${String(v).replace(/"/g, '""')}"`;
  return '\ufeff' + [r.columns, ...r.rows].map((row) => row.map(q).join(',')).join('\r\n');
}

module.exports = {
  init, list, save, remove, returnLoan, renewLoan, settleFine, cancelReservation,
  getSettings, saveSettings, stats, report, reportCsv, dump, restore, today, addDays
};
