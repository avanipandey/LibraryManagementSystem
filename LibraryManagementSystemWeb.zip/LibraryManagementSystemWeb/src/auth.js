// Staff accounts and sessions. Passwords are hashed with scrypt; sessions live in memory.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const SESSION_MS = 8 * 60 * 60 * 1000;
const ROLES = ['admin', 'librarian'];
let file = null;
let staff = [];
const sessions = new Map(); // token -> { staffId, expires }

const hash = (password, salt) => crypto.scryptSync(password, salt, 64);
const DUMMY_SALT = crypto.randomBytes(16);

function init(filePath) {
  file = filePath;
  fs.mkdirSync(path.dirname(file), { recursive: true });
  staff = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
  sessions.clear();
}

function persist() {
  const tmp = file + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(staff, null, 2), { mode: 0o600 });
  fs.renameSync(tmp, file);
}

const publicView = (s) => ({ id: s.id, username: s.username, name: s.name, role: s.role, createdAt: s.createdAt });
const needsSetup = () => staff.length === 0;
const listStaff = () => staff.map(publicView);
const text = (v) => (v == null ? '' : String(v).trim());

function checkFields({ username, name, role, password }, { requirePassword }) {
  const out = { username: text(username).toLowerCase(), name: text(name), role: ROLES.includes(role) ? role : 'librarian' };
  if (!/^[a-z0-9._-]{3,32}$/.test(out.username)) throw new Error('Username must be 3-32 characters: letters, numbers, dot, dash or underscore.');
  if (!out.name) throw new Error('Name is required.');
  if (requirePassword || password) {
    if (typeof password !== 'string' || password.length < 8) throw new Error('Password must be at least 8 characters.');
    if (password.length > 200) throw new Error('Password is too long.');
  }
  return out;
}

function setPassword(s, password) {
  const salt = crypto.randomBytes(16);
  s.salt = salt.toString('hex');
  s.hash = hash(password, salt).toString('hex');
}

function createStaff(input) {
  const out = checkFields(input, { requirePassword: true });
  if (staff.some((s) => s.username === out.username)) throw new Error('That username is already taken.');
  const s = { id: crypto.randomUUID(), ...out, createdAt: new Date().toISOString() };
  setPassword(s, input.password);
  staff.push(s);
  persist();
  return publicView(s);
}

const adminCount = () => staff.filter((s) => s.role === 'admin').length;

function updateStaff(id, input) {
  const s = staff.find((x) => x.id === id);
  if (!s) throw new Error('This account no longer exists.');
  const out = checkFields({ ...input, role: input.role }, { requirePassword: false });
  if (staff.some((x) => x.id !== id && x.username === out.username)) throw new Error('That username is already taken.');
  if (s.role === 'admin' && out.role !== 'admin' && adminCount() <= 1) throw new Error('There must be at least one administrator.');
  const changedAccess = Boolean(input.password) || out.role !== s.role;
  Object.assign(s, out);
  if (input.password) setPassword(s, input.password);
  if (changedAccess) dropSessions(id);
  persist();
  return publicView(s);
}

function removeStaff(id, actorId) {
  const s = staff.find((x) => x.id === id);
  if (!s) throw new Error('This account no longer exists.');
  if (id === actorId) throw new Error("You can't delete your own account.");
  if (s.role === 'admin' && adminCount() <= 1) throw new Error('There must be at least one administrator.');
  staff = staff.filter((x) => x.id !== id);
  dropSessions(id);
  persist();
  return true;
}

function verify(username, password) {
  const s = staff.find((x) => x.username === text(username).toLowerCase());
  const salt = s ? Buffer.from(s.salt, 'hex') : DUMMY_SALT;
  const given = hash(typeof password === 'string' ? password.slice(0, 200) : '', salt);
  if (!s) return null;
  return crypto.timingSafeEqual(given, Buffer.from(s.hash, 'hex')) ? s : null;
}

function createSession(staffId) {
  const token = crypto.randomBytes(32).toString('hex');
  sessions.set(token, { staffId, expires: Date.now() + SESSION_MS });
  return token;
}

function userFor(token) {
  const sess = token && sessions.get(token);
  if (!sess) return null;
  const s = staff.find((x) => x.id === sess.staffId);
  if (!s || sess.expires < Date.now()) { sessions.delete(token); return null; }
  sess.expires = Date.now() + SESSION_MS; // sliding expiry
  return s;
}

const destroySession = (token) => sessions.delete(token);
function dropSessions(staffId) {
  for (const [t, s] of sessions) if (s.staffId === staffId) sessions.delete(t);
}

module.exports = { init, needsSetup, listStaff, createStaff, updateStaff, removeStaff, verify, createSession, userFor, destroySession, publicView, SESSION_MS };
