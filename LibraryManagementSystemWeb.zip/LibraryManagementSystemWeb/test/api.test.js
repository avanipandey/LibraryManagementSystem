// End-to-end tests: start the real server and talk to it over HTTP like the browser does.
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { createServer } = require('../server');

const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'lms-web-'));
const server = createServer({ dataDir });

function client(base) {
  let cookie = '';
  const call = async (method, url, body, extra = {}) => {
    const headers = { ...extra };
    if (method !== 'GET' && !('X-Requested-With' in extra)) headers['X-Requested-With'] = 'fetch';
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    if (cookie) headers.Cookie = cookie;
    const res = await fetch(base + url, { method, headers, body: body === undefined ? undefined : JSON.stringify(body), redirect: 'manual' });
    const set = res.headers.get('set-cookie');
    if (set) cookie = set.startsWith('lms_session=;') ? '' : set.split(';')[0];
    const type = res.headers.get('content-type') || '';
    const data = type.includes('json') ? await res.json() : await res.text();
    return { status: res.status, data, headers: res.headers };
  };
  return { call, get cookie() { return cookie; } };
}

(async () => {
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${server.address().port}`;
  const admin = client(base);
  const ok = async (p) => { const r = await p; assert.ok(r.status < 300, `expected success, got ${r.status}: ${JSON.stringify(r.data)}`); return r.data; };
  const fails = async (p, status, pattern) => { const r = await p; assert.strictEqual(r.status, status, `expected ${status}, got ${r.status}: ${JSON.stringify(r.data)}`); if (pattern) assert.match(r.data.error, pattern); };

  // --- static files and security headers ---
  const home = await admin.call('GET', '/');
  assert.strictEqual(home.status, 200);
  assert.match(home.data, /LibraryManagementSystem/);
  assert.match(home.headers.get('content-security-policy'), /default-src 'self'/);
  assert.strictEqual(home.headers.get('x-frame-options'), 'DENY');
  assert.strictEqual((await admin.call('GET', '/app.js')).status, 200);
  assert.strictEqual((await admin.call('GET', '/..%2fserver.js')).status, 403, 'path traversal is blocked');
  assert.strictEqual((await admin.call('GET', '/nope.txt')).status, 404);

  // --- first-run setup and sign-in ---
  let session = await ok(admin.call('GET', '/api/session'));
  assert.strictEqual(session.setupRequired, true);
  assert.strictEqual(session.user, null);
  await fails(admin.call('GET', '/api/books'), 401);
  await fails(admin.call('POST', '/api/setup', { name: 'Ada', username: 'ada', password: 'short' }), 400, /8 characters/);
  const setup = await ok(admin.call('POST', '/api/setup', { name: 'Ada Admin', username: 'Ada', password: 'correct horse' }));
  assert.strictEqual(setup.user.role, 'admin');
  assert.ok(admin.cookie.startsWith('lms_session='));
  await fails(admin.call('POST', '/api/setup', { name: 'Eve', username: 'eve', password: 'password123' }), 403);
  session = await ok(admin.call('GET', '/api/session'));
  assert.strictEqual(session.user.username, 'ada');
  assert.strictEqual(session.setupRequired, false);

  // --- CSRF defences ---
  await fails(admin.call('POST', '/api/books', {}, { 'X-Requested-With': '' }), 403);
  await fails(admin.call('POST', '/api/books', {}, { Origin: 'http://evil.example' }), 403, /Cross-site/);

  // --- catalogue ---
  const sections = await ok(admin.call('GET', '/api/sections'));
  assert.strictEqual(sections.length, 3);
  const book = await ok(admin.call('POST', '/api/books', { title: 'Dune', author: 'Frank Herbert', sectionId: sections[0].id, copies: 1, isbn: '111' }));
  await fails(admin.call('POST', '/api/books', { title: 'Dup', author: 'X', sectionId: sections[0].id, copies: 1, isbn: '111' }), 400, /ISBN/);
  const edited = await ok(admin.call('PUT', `/api/books/${book.id}`, { title: 'Dune Messiah', author: 'Frank Herbert', sectionId: sections[0].id, copies: 1, isbn: '111' }));
  assert.strictEqual(edited.title, 'Dune Messiah');
  await fails(admin.call('GET', '/api/staff-secrets'), 404);
  await fails(admin.call('POST', '/api/fines', {}), 404);

  // --- circulation ---
  const member = await ok(admin.call('POST', '/api/users', { name: 'Asha', email: 'asha@example.com' }));
  const other = await ok(admin.call('POST', '/api/users', { name: 'Ravi', email: 'ravi@example.com' }));
  const today = session.today;
  const loan = await ok(admin.call('POST', '/api/loans', { bookId: book.id, userId: member.id, issuedOn: today, dueOn: today }));
  await fails(admin.call('POST', '/api/loans', { bookId: book.id, userId: other.id, issuedOn: today, dueOn: today }), 400, /No copies/);
  const res = await ok(admin.call('POST', '/api/reservations', { bookId: book.id, userId: other.id }));
  assert.strictEqual(res.status, 'Waiting');
  await fails(admin.call('POST', `/api/loans/${loan.id}/renew`), 400, /waiting/);
  await ok(admin.call('POST', `/api/loans/${loan.id}/return`, {}));
  assert.strictEqual((await ok(admin.call('GET', '/api/reservations')))[0].status, 'Ready');
  await fails(admin.call('DELETE', `/api/books/${book.id}/extra`), 404);

  // --- dashboard, reports, csv ---
  const stats = await ok(admin.call('GET', '/api/stats'));
  assert.strictEqual(stats.titles, 1);
  const rep = await ok(admin.call('GET', '/api/reports/inventory'));
  assert.deepStrictEqual(rep.columns, ['Section', 'Titles', 'Copies', 'On loan', 'On shelf']);
  const csv = await admin.call('GET', '/api/reports/popular/csv');
  assert.match(csv.headers.get('content-disposition'), /attachment; filename="popular-report-/);
  assert.match(csv.data, /Dune Messiah/);
  await fails(admin.call('GET', '/api/reports/bogus'), 400, /Unknown report/);

  // --- staff, roles and permissions ---
  const lib = await ok(admin.call('POST', '/api/staff', { name: 'Lia Librarian', username: 'lia', role: 'librarian', password: 'library-pass' }));
  assert.ok(!('hash' in lib) && !('salt' in lib), 'password hashes are never returned');
  await fails(admin.call('POST', '/api/staff', { name: 'Dup', username: 'LIA', role: 'librarian', password: 'library-pass' }), 400, /taken/);
  const staff = client(base);
  await fails(staff.call('POST', '/api/login', { username: 'lia', password: 'wrong-password' }), 401, /Incorrect/);
  await ok(staff.call('POST', '/api/login', { username: 'LIA', password: 'library-pass' }));
  await ok(staff.call('GET', '/api/books'));
  await fails(staff.call('GET', '/api/staff'), 403);
  await fails(staff.call('PUT', '/api/settings', {}), 403);
  await fails(staff.call('GET', '/api/backup'), 403);
  await fails(staff.call('POST', '/api/restore', { books: [], users: [], sections: [] }), 403);
  await ok(staff.call('GET', '/api/settings'));
  await fails(admin.call('DELETE', `/api/staff/${setup.user.id}`), 400, /own account/);
  await fails(admin.call('PUT', `/api/staff/${setup.user.id}`, { name: 'Ada', username: 'ada', role: 'librarian' }), 400, /at least one administrator/);

  // password reset signs the user out everywhere
  await ok(admin.call('PUT', `/api/staff/${lib.id}`, { name: 'Lia Librarian', username: 'lia', role: 'librarian', password: 'new-library-pass' }));
  await fails(staff.call('GET', '/api/books'), 401);
  await ok(staff.call('POST', '/api/login', { username: 'lia', password: 'new-library-pass' }));

  // --- settings, backup, restore ---
  const settings = await ok(admin.call('PUT', '/api/settings', { ...(await ok(admin.call('GET', '/api/settings'))), libraryName: 'Riverside Library', loanDays: 21 }));
  assert.strictEqual(settings.loanDays, 21);
  await fails(admin.call('PUT', '/api/settings', { ...settings, loanDays: 0 }), 400, /Loan period/);
  const backup = await admin.call('GET', '/api/backup');
  assert.match(backup.headers.get('content-disposition'), /attachment/);
  const snapshot = backup.data;
  assert.strictEqual(snapshot.books.length, 1);
  await ok(admin.call('DELETE', `/api/loans/${loan.id}`));
  await ok(admin.call('DELETE', `/api/reservations/${res.id}`));
  await ok(admin.call('DELETE', `/api/books/${book.id}`));
  assert.strictEqual((await ok(admin.call('GET', '/api/books'))).length, 0);
  await ok(admin.call('POST', '/api/restore', snapshot));
  assert.strictEqual((await ok(admin.call('GET', '/api/books'))).length, 1);
  await fails(admin.call('POST', '/api/restore', { nope: true }), 400, /not a LibraryManagementSystem backup/);
  const bad = await fetch(base + '/api/books', { method: 'POST', headers: { 'X-Requested-With': 'fetch', 'Content-Type': 'application/json', Cookie: admin.cookie }, body: '{oops' });
  assert.strictEqual(bad.status, 400);

  // --- sign out ---
  await ok(admin.call('POST', '/api/logout', {}));
  await fails(admin.call('GET', '/api/books'), 401);

  // --- login lockout after repeated failures ---
  const attacker = client(base);
  for (let i = 0; i < 5; i++) await fails(attacker.call('POST', '/api/login', { username: 'ada', password: 'nope-nope' }), 401);
  await fails(attacker.call('POST', '/api/login', { username: 'ada', password: 'correct horse' }), 429, /Too many/);

  // staff accounts persist separately from library data
  assert.ok(fs.existsSync(path.join(dataDir, 'staff.json')));
  assert.ok(!fs.readFileSync(path.join(dataDir, 'library-data.json'), 'utf8').includes('correct horse'));

  server.close();
  console.log('All API tests passed');
})().catch((err) => { console.error(err); process.exit(1); });
