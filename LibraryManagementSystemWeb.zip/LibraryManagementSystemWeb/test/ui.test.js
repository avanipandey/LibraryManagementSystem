// Runs the browser code (api.js + app.js) in a stubbed DOM against the real server.
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const vm = require('vm');
const { createServer } = require('../server');

const server = createServer({ dataDir: fs.mkdtempSync(path.join(os.tmpdir(), 'lms-ui-')) });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function makeBrowser(base) {
  let cookie = '';
  const els = {};
  const docListeners = {};
  const winListeners = {};
  const el = (id) => els[id] || (els[id] = {
    id, innerHTML: '', textContent: '', hidden: false, className: '', value: '', checked: false, returnValue: '', dataset: {}, listeners: {},
    addEventListener(n, f) { this.listeners[n] = f; }, showModal() {}, close() {}, click() {}, focus() {}, querySelector: () => ({ focus() {} })
  });
  const fetchWithCookies = async (url, opts = {}) => {
    const res = await fetch(base + url, { ...opts, headers: { ...(opts.headers || {}), ...(cookie ? { Cookie: cookie } : {}) } });
    const set = res.headers.get('set-cookie');
    if (set) cookie = set.startsWith('lms_session=;') ? '' : set.split(';')[0];
    return res;
  };
  const ctx = {
    console, setTimeout, clearTimeout, Date, fetch: fetchWithCookies, location: {},
    Event: class { constructor(type) { this.type = type; } },
    document: { getElementById: el, addEventListener: (n, f) => (docListeners[n] = f) }
  };
  ctx.window = { addEventListener: (n, f) => (winListeners[n] = f), dispatchEvent: (e) => winListeners[e.type] && winListeners[e.type](e) };
  vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(path.join(__dirname, '../public/api.js'), 'utf8'), ctx);
  vm.runInContext(fs.readFileSync(path.join(__dirname, '../public/app.js'), 'utf8') + '\n;globalThis.__go = go; globalThis.__state = state;', ctx);
  const click = (dataset) => docListeners.click({ target: { closest: () => ({ dataset }) } });
  const submitAuth = async (vals) => {
    for (const [k, v] of Object.entries(vals)) el('a-' + k).value = v;
    await els['auth-form'].listeners.submit({ preventDefault() {} });
    await sleep(150);
  };
  return { ctx, els, el, click, submitAuth };
}

(async () => {
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${server.address().port}`;

  // first run: setup screen, then the app
  const b = makeBrowser(base);
  await sleep(200);
  assert.strictEqual(b.els.auth.hidden, false);
  assert.match(b.els['auth-title'].textContent, /Create the administrator/);
  await b.submitAuth({ name: 'Ada Admin', username: 'ada', password: 'wrong' });
  assert.match(b.els['auth-error'].textContent, /8 characters/);
  await b.submitAuth({ name: 'Ada Admin', username: 'ada', password: 'correct horse' });
  assert.strictEqual(b.els.app.hidden, false);
  assert.match(b.els.view.innerHTML, /Dashboard/);
  assert.match(b.els.nav.innerHTML, /Staff/);
  assert.match(b.els['user-box'].innerHTML, /Ada Admin/);

  // seed through the real API, then render every screen
  const api = b.ctx.window.api;
  const sec = (await api.list('sections')).data[0];
  const book = (await api.save('books', { title: 'Dune <i>', author: 'FH', sectionId: sec.id, copies: 1 })).data;
  const member = (await api.save('users', { name: 'Asha', email: 'a@x.com' })).data;
  assert.ok((await api.save('loans', { bookId: book.id, userId: member.id, issuedOn: '2020-01-01', dueOn: '2020-01-10' })).ok);
  for (const v of ['dashboard', 'books', 'sections', 'users', 'loans', 'reservations', 'fines', 'reports', 'staff', 'settings']) {
    await b.ctx.__go(v);
    assert.ok(b.els.view.innerHTML.length > 200 && !b.els.view.innerHTML.includes('undefined'), 'renders ' + v);
  }
  await b.ctx.__go('books');
  assert.ok(b.els.tbody.innerHTML.includes('Dune &lt;i&gt;'), 'user text is escaped');
  await b.ctx.__go('loans');
  assert.ok(b.els.tbody.innerHTML.includes('Overdue'));

  // actions: return a late loan, see the fine
  b.click({ act: 'return', id: (await api.list('loans')).data[0].id });
  await sleep(200);
  await b.ctx.__go('fines');
  assert.ok(b.els.tbody.innerHTML.includes('Unpaid'));

  // sign out, then sign in again as a librarian (no admin screens)
  await api.save('staff', { name: 'Lia', username: 'lia', role: 'librarian', password: 'library-pass' });
  b.click({ act: 'logout' });
  await sleep(150);
  assert.strictEqual(b.els.auth.hidden, false);
  assert.match(b.els['auth-title'].textContent, /Sign in/);
  await b.submitAuth({ username: 'lia', password: 'nope-nope-nope' });
  assert.match(b.els['auth-error'].textContent, /Incorrect/);
  await b.submitAuth({ username: 'lia', password: 'library-pass' });
  assert.strictEqual(b.els.app.hidden, false);
  assert.ok(!/Staff|Settings/.test(b.els.nav.innerHTML), 'librarians do not see admin screens');
  await b.ctx.__go('books');
  assert.ok(b.els.tbody.innerHTML.includes('Dune'));

  server.close();
  console.log('All UI tests passed');
})().catch((err) => { console.error(err); process.exit(1); });
