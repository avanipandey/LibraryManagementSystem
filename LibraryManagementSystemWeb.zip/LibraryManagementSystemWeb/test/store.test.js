const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const store = require('../src/store');

const file = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'lms-')), 'data.json');
store.init(file);
const today = store.today();
const due = store.addDays(today, 14);
const lend = (b, u, extra = {}) => store.save('loans', { bookId: b.id, userId: u.id, issuedOn: today, dueOn: due, ...extra });

store.saveSettings({ libraryName: 'Test Library', currency: '$', loanDays: 14, maxLoans: 2, maxRenewals: 1, finePerDay: 2, blockOnFines: true });
const sections = store.list('sections');
assert.strictEqual(sections.length, 3, 'seeds three sections');

// --- catalogue & members ---
const dune = store.save('books', { title: 'Dune', author: 'Frank Herbert', isbn: '123', sectionId: sections[0].id, copies: '2', year: '1965' });
const emma = store.save('books', { title: 'Emma', author: 'Jane Austen', sectionId: sections[0].id, copies: 1 });
const cosmos = store.save('books', { title: 'Cosmos', author: 'Carl Sagan', sectionId: sections[1].id, copies: 3 });
assert.throws(() => store.save('books', { title: 'X', author: 'Y', isbn: '123', sectionId: sections[0].id, copies: 1 }), /ISBN/);
assert.throws(() => store.save('books', { title: 'X', author: 'Y', sectionId: 'nope', copies: 1 }), /section/);
const asha = store.save('users', { name: 'Asha', email: 'ASHA@example.com' });
const ravi = store.save('users', { name: 'Ravi', email: 'ravi@example.com' });
const meena = store.save('users', { name: 'Meena', email: 'meena@example.com' });
const sam = store.save('users', { name: 'Sam', email: 'sam@example.com', status: 'Suspended' });
assert.strictEqual(asha.email, 'asha@example.com');
assert.strictEqual(asha.memberNo, 'M0001');
assert.strictEqual(meena.memberNo, 'M0003');
assert.throws(() => store.save('users', { name: 'B', email: 'asha@example.com' }), /email/);

// --- lending rules ---
const loan1 = lend(dune, asha);
assert.strictEqual(store.list('books').find((b) => b.id === dune.id).available, 1);
assert.throws(() => lend(dune, asha), /already has/);
assert.throws(() => lend(dune, sam), /suspended/);
assert.throws(() => lend(dune, ravi, { dueOn: '2000-01-01' }), /before the issue/);
const loanEmma = lend(emma, asha);
assert.throws(() => lend(cosmos, asha), /limit of 2/);
assert.throws(() => store.remove('books', dune.id), /on loan/);
assert.throws(() => store.remove('users', asha.id), /on loan/);
assert.throws(() => store.save('books', { id: dune.id, title: 'Dune', author: 'FH', isbn: '123', sectionId: sections[0].id, copies: 0 }), /Copies must/);

// --- renewals ---
const renewed = store.renewLoan(loan1.id);
assert.strictEqual(renewed.dueOn, store.addDays(due, 14));
assert.throws(() => store.renewLoan(loan1.id), /Maximum of 1/);
assert.strictEqual(store.save('loans', { id: loan1.id, dueOn: due }).dueOn, due);

// --- reservations ---
assert.throws(() => store.save('reservations', { bookId: dune.id, userId: ravi.id }), /available/);
const res = store.save('reservations', { bookId: emma.id, userId: ravi.id });
assert.strictEqual(res.status, 'Waiting');
assert.throws(() => store.save('reservations', { bookId: emma.id, userId: ravi.id }), /already reserved/);
assert.throws(() => store.save('reservations', { bookId: emma.id, userId: asha.id }), /already has/);
store.save('reservations', { bookId: emma.id, userId: meena.id });
assert.throws(() => store.renewLoan(loanEmma.id), /waiting/);
store.returnLoan(loanEmma.id);
let rs = store.list('reservations');
assert.strictEqual(rs[0].status, 'Ready', 'first in queue gets the returned copy');
assert.strictEqual(rs[1].status, 'Waiting');
assert.throws(() => lend(emma, meena), /No copies/);
lend(emma, ravi);
assert.strictEqual(store.list('reservations')[0].status, 'Fulfilled');
store.cancelReservation(rs[1].id);
assert.throws(() => store.cancelReservation(rs[1].id), /already cancelled/);

// --- fines ---
const late = store.save('loans', { bookId: cosmos.id, userId: meena.id, issuedOn: '2020-01-01', dueOn: '2020-01-15' });
assert.strictEqual(store.list('loans').find((l) => l.id === late.id).status, 'Overdue');
assert.strictEqual(store.list('fines')[0].status, 'Accruing');
assert.throws(() => store.settleFine(late.id, 'Paid'), /returned/);
const returned = store.returnLoan(late.id);
assert.ok(returned.fineAmount > 0);
assert.strictEqual(returned.fineAmount % 2, 0, 'fine uses the per-day rate');
assert.strictEqual(store.list('fines')[0].status, 'Unpaid');
assert.throws(() => lend(cosmos, meena), /unpaid fines/);
assert.strictEqual(store.stats().unpaidFines, returned.fineAmount);
store.settleFine(late.id, 'Paid');
assert.throws(() => store.settleFine(late.id, 'Waived'), /already paid/);
lend(cosmos, meena);

// --- reports, dashboard, settings ---
const s = store.stats();
assert.strictEqual(s.titles, 3);
assert.ok(s.popular.length > 0 && s.recent.length > 0);
assert.deepStrictEqual(store.report('inventory').columns.length, 5);
assert.ok(store.reportCsv('popular').startsWith('\ufeff"Title","Author"'));
assert.throws(() => store.report('nope'), /Unknown report/);
assert.throws(() => store.saveSettings({ ...store.getSettings(), loanDays: 0 }), /Loan period/);

// --- cleanup rules and persistence ---
store.returnLoan(store.list('loans').find((l) => l.bookId === cosmos.id && !l.returnedOn).id);
store.returnLoan(store.list('loans').find((l) => l.bookId === emma.id && !l.returnedOn).id);
store.returnLoan(loan1.id);
store.remove('books', dune.id);
assert.throws(() => store.remove('sections', sections[0].id), /still has 1 book/);
const backup = store.dump();
store.init(file);
assert.strictEqual(store.list('books').length, 2);
store.restore({ ...backup, books: [] });
assert.strictEqual(store.list('books').length, 0);
assert.throws(() => store.restore({ nope: true }), /not a LibraryManagementSystem backup/);
console.log('All store tests passed');
