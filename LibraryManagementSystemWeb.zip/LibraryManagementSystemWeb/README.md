# LibraryManagementSystem (Web)

A web application for running a library, built with Node.js. No dependencies to install: it uses only Node's built-in modules (Node 18 or newer).

## Run
```bash
npm start
```
Open http://localhost:3000. On the first visit you create the administrator account, then sign in.

| Setting | Default | Purpose |
| --- | --- | --- |
| `PORT` | `3000` | Port to listen on |
| `HOST` | `127.0.0.1` | Use `0.0.0.0` to let other computers on your network connect |
| `DATA_DIR` | `./data` | Where library data and staff accounts are stored |
| `COOKIE_SECURE` | off | Set to `1` when serving over HTTPS |

Example for a library network: `HOST=0.0.0.0 PORT=8080 DATA_DIR=/var/lib/library npm start`

If you expose it beyond your own network, put it behind an HTTPS reverse proxy (nginx, Caddy) and set `COOKIE_SECURE=1`.

## Tools
- **Dashboard**: totals, due today, overdue, reservations, unpaid fines, most borrowed, recent activity
- **Books and Sections**: catalogue with ISBN, copies and live availability
- **Members**: automatic membership numbers, Active / Suspended
- **Loans**: lend, return, renew, change due date. Overdue highlighting
- **Reservations**: queue for books with no free copies; a returned copy is held for the first in line
- **Fines**: per-day late fines recorded on return; mark paid or waive
- **Reports**: overdue, most borrowed, inventory, member activity, fines. Download as CSV
- **Staff** (admin): add librarians and administrators, reset passwords
- **Settings** (admin): library name, currency, loan period, limits, fine rate, backup and restore

## Roles
- **Administrator**: everything, including staff accounts, settings, backup and restore
- **Librarian**: catalogue, members, circulation, reservations, fines and reports

## Security
Passwords are hashed with scrypt. Sessions use HttpOnly, SameSite=Strict cookies that expire after 8 idle hours. State-changing requests require a custom header and a same-origin check. Five failed sign-ins lock that address out for five minutes. A strict Content-Security-Policy is sent on every page. Staff accounts are stored apart from library data, so restoring a backup never touches them.

## Tests
```bash
npm test
```
Covers the library rules, the HTTP API (sign-in, roles, CSRF, backup/restore) and the browser code.

## Layout
`server.js` HTTP server and API, `src/store.js` library data and rules, `src/auth.js` staff and sessions, `public/` the browser app, `test/` tests.

To keep it running on a server, use a process manager such as systemd or pm2.
